const overlay = `
<div id="lg-overlay"
style="
position: fixed;
top: 0;
left: 0;
width: 100vw;
height: 100vh;
pointer-events: none;
z-index: 9999999;
backdrop-filter: blur(18px) brightness(1.18) saturate(1.1);
background: 
    url('../ui/shine.png') center/cover no-repeat,
    radial-gradient(circle at 40% 40%, rgba(255,255,255,.18), transparent 70%);
animation: wobble 6s ease-in-out infinite, shineRotate 14s linear infinite;
">
</div>

<style>

@keyframes wobble {
  0%   { transform: scale(1.00) translate(0px,0px); }
  25%  { transform: scale(1.02) translate(1px,-2px); }
  50%  { transform: scale(1.01) translate(-1px,1px); }
  75%  { transform: scale(1.03) translate(2px,-1px); }
  100% { transform: scale(1.00) translate(0px,0px); }
}

@keyframes shineRotate {
  0%   { filter: brightness(1.0); transform: rotate(0deg); }
  50%  { filter: brightness(1.25); }
  100% { transform: rotate(360deg); filter: brightness(1.0); }
}

</style>
`;

document.body.insertAdjacentHTML("beforeend", overlay);
